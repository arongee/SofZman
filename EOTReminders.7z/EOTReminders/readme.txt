Step-by-Step in Visual Studio
1. Set the Files as Embedded Resources
For each file in /Assets/:

Right-click the file → Properties

Set:

pgsql
Copy
Edit
Build Action: Embedded Resource
Copy to Output Directory: Do not copy
✅ This makes sure all images and .wav files are packed into the .exe.

2. Access Embedded Files in Code
You're already doing it right for .wav files:

csharp
Copy
Edit
var stream = Assembly.GetExecutingAssembly()
    .GetManifestResourceStream("EOTReminder.Assets.alert10.wav");
Same applies for images:

In XAML, you reference via relative path: /Assets/clock.png

But that expects files to be copied — so instead...

📌 Convert your image references to use embedded resources (WPF trick):

xml
Copy
Edit
<Image Source="pack://application:,,,/YourAssemblyName;component/Assets/clock.png"/>
Replace YourAssemblyName with your actual project name.

3. Mark XAML Images as Resource (not Embedded Resource)
For .png, .jpg used in XAML:

Set:

yaml
Copy
Edit
Build Action: Resource
💡 This is different than .wav which should be Embedded Resource.

4. Leave DailyTimes.xlsx External
Put it next to your .exe after build:

Copy
Edit
MyApp/
├── EOTReminder.exe
└── DailyTimes.xlsx
In code you're already reading:

csharp
Copy
Edit
string path = "DailyTimes.xlsx";
That’s perfect — keep it like that.

5. Build the EXE
In Visual Studio:

Set Release mode

Menu: Build > Build Solution

Output is in:

bash
Copy
Edit
bin/Release/net6.0-windows/
6. Optional: Single-File Publish (for distribution)
To bundle everything into one .exe:

bash
Copy
Edit
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeAllContentForSelfExtract=true
That will generate a single .exe with everything except DailyTimes.xlsx.

🔁 Summary
File Type	Build Action	Used In	Location
.wav	Embedded Resource	C# (Play)	Access via GetManifestResourceStream()
.png	Resource	XAML	Use pack://application:,,,/...
.jpg	Resource	Background	Same as .png
.xlsx	None (leave external)	C# (Load)	Next to .exe

Let me know if you want a .csproj example with all of this set, or a publish command tailored to your project.