
// ViewModels/MainViewModel.cs - Full MVVM Features

using EOTReminder.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Timers;
using OfficeOpenXml;

namespace EOTReminder.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<TimeSlot> TimeSlots { get; set; } = new();
        public string TodayDate => DateTime.Now.ToString("dd/MM/yyyy");
        public string CurrentTime => DateTime.Now.ToString("HH:mm:ss");
        public string HebrewDate => GetHebrewDate(DateTime.Now);
        public string Sunrise { get; set; }
        public string Midday { get; set; }
        public string Sunset { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private Timer _timer;
        private string _currentLang = "en";

        private readonly Dictionary<string, Dictionary<string, string>> _translations = new()
        {
            ["en"] = new()
            {
                ["EOS1"] = "End of Shema (3h from day start)",
                ["EOS2"] = "End of Shema (3h from sunrise)",
                ["EOT1"] = "End of Prayer (4h from day start)",
                ["EOT2"] = "End of Prayer (4h from sunrise)",
                ["Passed"] = "Passed"
            },
            ["he"] = new()
            {
                ["EOS1"] = "סו" + "ף קר" + "יאת שמע (3 שעות מהתחלת היום)",
                ["EOS2"] = "סוף קריאת שמע (3 שעות מזריחה)",
                ["EOT1"] = "סוף תפילה (4 שעות מהתחלת היום)",
                ["EOT2"] = "סוף תפילה (4 שעות מזריחה)",
                ["Passed"] = "עבר"
            }
        };

        public MainViewModel()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            LoadFromExcel();
            InitTimer();
        }

        private void InitTimer()
        {
            _timer = new Timer(1000);
            _timer.Elapsed += (s, e) =>
            {
                foreach (var slot in TimeSlots)
                {
                    if (!slot.IsPassed && slot.Countdown <= TimeSpan.Zero)
                    {
                        slot.IsPassed = true;
                        slot.CountdownText = "";
                        slot.ShowSandClock = false;
                    }
                    else if (!slot.IsPassed)
                    {
                        slot.CountdownText = string.Format("{0:D2}:{1:D2}",
                            (int)slot.Countdown.TotalMinutes,
                            slot.Countdown.Seconds);

                        if (!slot.AlertFlags["30"] && slot.Countdown.TotalMinutes <= 30)
                        {
                            slot.Highlight = true;
                            slot.ShowSandClock = true;
                            slot.AlertFlags["30"] = true;
                        }
                        if (!slot.AlertFlags["10"] && slot.Countdown.TotalMinutes <= 10)
                        {
                            PlayAlert("alert10.wav");
                            slot.AlertFlags["10"] = true;
                        }
                        if (!slot.AlertFlags["3"] && slot.Countdown.TotalMinutes <= 3)
                        {
                            PlayAlert("alert3.wav");
                            slot.AlertFlags["3"] = true;
                        }
                    }
                }
                OnPropertyChanged(nameof(CurrentTime));
                OnPropertyChanged(nameof(TimeSlots));
            };
            _timer.Start();
        }

        private void LoadFromExcel()
        {
            string path = "DailyTimes.xlsx";
            if (!File.Exists(path))
            {
                LoadMock();
                return;
            }

            try
            {
                using var package = new ExcelPackage(new FileInfo(path));
                var ws = package.Workbook.Worksheets["Times"];
                var today = DateTime.Today;

                for (int row = 2; row <= ws.Dimension.End.Row; row++)
                {
                    if (DateTime.TryParse(ws.Cells[row, 1].Text, out DateTime date) && date.Date == today)
                    {
                        AddSlot("EOS1", ParseTime(ws.Cells[row, 2].Text));
                        AddSlot("EOS2", ParseTime(ws.Cells[row, 3].Text));
                        AddSlot("EOT1", ParseTime(ws.Cells[row, 4].Text));
                        AddSlot("EOT2", ParseTime(ws.Cells[row, 5].Text));

                        Sunrise = ParseTime(ws.Cells[row, 6].Text).ToString("HH:mm:ss");
                        Midday = ParseTime(ws.Cells[row, 7].Text).ToString("HH:mm:ss");
                        Sunset = ParseTime(ws.Cells[row, 8].Text).ToString("HH:mm:ss");
                        return;
                    }
                }
                LoadMock();
            }
            catch
            {
                LoadMock();
            }
        }

        private DateTime ParseTime(string input)
        {
            if (TimeSpan.TryParse(input, out var ts))
                return DateTime.Today.Add(ts);
            if (DateTime.TryParse(input, out var dt))
                return dt;
            return DateTime.Now.AddMinutes(1);
        }

        private void LoadMock()
        {
            var now = DateTime.Now;
            AddSlot("EOS1", now.AddMinutes(5));
            AddSlot("EOS2", now.AddMinutes(10));
            AddSlot("EOT1", now.AddMinutes(20));
            AddSlot("EOT2", now.AddMinutes(30));

            Sunrise = "06:00:00";
            Midday = "12:00:00";
            Sunset = "18:00:00";
        }

        private void AddSlot(string id, DateTime time)
        {
            TimeSlots.Add(new TimeSlot
            {
                Id = id,
                Description = _translations[_currentLang][id],
                Time = time,
                IsPassed = false,
                CountdownText = "",
                ShowSandClock = false,
                Highlight = false
            });
        }

        private void PlayAlert(string resourceName)
        {
            try
            {
                var stream = Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream($"EOTReminder.Assets.{resourceName}");
                if (stream != null)
                {
                    SoundPlayer player = new(stream);
                    player.Play();
                }
            }
            catch { /* ignore */ }
        }

        private string GetHebrewDate(DateTime date)
        {
            var hc = new HebrewCalendar();
            int y = hc.GetYear(date);
            int m = hc.GetMonth(date);
            int d = hc.GetDayOfMonth(date);
            string[] hebMonths =
            {
                "", "ניסן", "אייר", "סיון", "תמוז", "אב", "אלול",
                "תשרי", "חשון", "כסלו", "טבת", "שבט", "אדר", "אדר ב'"
            };
            string month = (m >= 1 && m < hebMonths.Length) ? hebMonths[m] : m.ToString();
            return $"{d} {month} {y}";
        }

        public void SwitchLanguage(string lang)
        {
            _currentLang = lang;
            foreach (var slot in TimeSlots)
            {
                if (_translations[lang].TryGetValue(slot.Id, out var trans))
                    slot.Description = trans;
            }
            OnPropertyChanged(nameof(TimeSlots));
        }

        private void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}