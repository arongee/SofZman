
// App.xaml.cs

using System.Windows;

namespace EOTReminder
{
    public partial class App : Application
    {
    }
}