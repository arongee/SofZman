
// Models/TimeSlot.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace EOTReminder.Models
{
    public class TimeSlot : INotifyPropertyChanged
    {
        private string _description;
        private bool _isPassed;
        private string _countdownText;
        private bool _showSandClock;
        private bool _highlight;

        public string Id { get; set; }
        public DateTime Time { get; set; }
        public Dictionary<string, bool> AlertFlags { get; set; } = new() { ["30"] = false, ["10"] = false, ["3"] = false };

        public string Description
        {
            get => _description;
            set { _description = value; OnPropertyChanged(); }
        }

        public bool IsPassed
        {
            get => _isPassed;
            set { _isPassed = value; OnPropertyChanged(); }
        }

        public string CountdownText
        {
            get => _countdownText;
            set { _countdownText = value; OnPropertyChanged(); }
        }

        public bool ShowSandClock
        {
            get => _showSandClock;
            set { _showSandClock = value; OnPropertyChanged(); }
        }

        public bool Highlight
        {
            get => _highlight;
            set { _highlight = value; OnPropertyChanged(); }
        }

        public TimeSpan Countdown => Time - DateTime.Now;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}