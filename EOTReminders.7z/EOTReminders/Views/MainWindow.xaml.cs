
// Views/MainWindow.xaml.cs

using System.Windows;
using System.Windows.Controls;
using EOTReminder.ViewModels;

namespace EOTReminder.Views
{
    public partial class MainWindow : Window
    {
        private MainViewModel _viewModel => DataContext as MainViewModel;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Optional: Language switcher handler if you add ComboBox in XAML later
        private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems[0] is ComboBoxItem selected)
            {
                string lang = selected.Tag?.ToString();
                if (!string.IsNullOrWhiteSpace(lang))
                    _viewModel?.SwitchLanguage(lang);
            }
        }
    }
}